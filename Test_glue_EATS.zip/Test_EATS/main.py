import os
import requests
import numpy as np
from PIL import Image
from io import BytesIO
#from requests.adapters import HTTPAdapter
#from urllib3.util.retry import Retry


APP_URL = "http://localhost:8888/app-api"
JOB_ID = os.environ.get('EMPAIA_JOB_ID')
TOKEN = os.environ.get('EMPAIA_TOKEN')
HEADER = {"Authorization": f"Bearer {TOKEN}"}

print(TOKEN)
print(HEADER)

# Retrieve meta-data
input_url = f"{APP_URL}/v3/{JOB_ID}/inputs/my_wsi"
print(input_url)

#session = requests.Session()
#retry = Retry(connect=3, backoff_factor=0.5)
#adapter = HTTPAdapter(max_retries=retry)
#session.mount('http://', adapter)
#session.mount('https://', adapter)

#session.get(url)

r = requests.get(input_url, headers=HEADER)
r.raise_for_status()
wsi_meta = r.json()
wsi_id = wsi_meta['id']

# Download tile (7,1) at level 2
tile_url = f"{APP_URL}/v3/{JOB_ID}/tiles/{wsi_id}/level/2/position/7/1"
r = requests.get(tile_url, headers=HEADER)
r.raise_for_status()
i = Image.open(BytesIO(r.content))
a = np.array(i)
print(a.shape)
print("Hello World")
# Do something cool with your multi-dimensional array of pixel-color values, like put it in a Neural Network or so...

